import re
x1 = "no_of_goose <=1 && breaker_status==true && stNum < prev_stNum && sqNum == 0+|+is_busy==false"
x1 = x1.strip()
x1 = x1.replace(" ", "")
print(re.sub('<(?!=)', ' >= ', x1))
#print(re.sub('<(?=)', ' > ', x1))

import re

str = "The rain in Spain falls mainly in the plain!"

#Check if the string contains either "falls" or "stays":

x = re.findall("falls?!hshs", str)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")
